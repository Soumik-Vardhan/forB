package oop.ica.part2;

/**
 *
 * @author : Sarika Akhil Yadav
 * @StudentID : S3215482
 */
public class PondlifeProduct {

    private int skuNumber, maxLength, minTemp, maxTemp, stock;
    private String product, notes;
    private double cost;

    public PondlifeProduct(int skuNumber, String product, String notes, int maxLength, int minTemp, int maxTemp, double cost, int stock) {
        this.skuNumber = skuNumber;
        this.product = product;
        this.notes = notes;
        this.maxLength = maxLength;
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
        this.cost = cost;
        this.stock = stock;
    }

    public int getSkuNumber() {
        return skuNumber;
    }

    public String getProduct() {
        return product;
    }

    public String getNotes() {
        return notes;
    }

    public int getMaxLength() {
        return maxLength;
    }

    public int getMinTemp() {
        return minTemp;
    }

    public int getMaxTemp() {
        return maxTemp;
    }

    public double getCost() {
        return cost;
    }

    public int getStock() {
        return stock;
    }

    public void increaseStock(int quantity) {
        this.stock += quantity;
    }

    public void decreaseStock(int quantity) {
        this.stock -= quantity;
    }

}
