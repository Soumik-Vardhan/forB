package oop.ica.part2;

/**
 *
 * @author : Sarika Akhil Yadav
 * @StudentID : S3215482
 */
public class YoFishItem {

    private int id, stock, lowTemp, highTemp;
    private double price, maxSize;
    private String item;

    public YoFishItem() {

    }

    public YoFishItem(int id, String item, double price, int stock, double maxSize, int lowTemp, int highTemp) {
        this.id = id;
        this.stock = stock;
        this.lowTemp = lowTemp;
        this.highTemp = highTemp;
        this.price = price;
        this.maxSize = maxSize;
        this.item = item;
    }

    public int getId() {
        return id;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getLowTemp() {
        return lowTemp;
    }

    public int getHighTemp() {
        return highTemp;
    }

    public double getPrice() {
        return price;
    }

    public double getMaxSize() {
        return maxSize;
    }

    public String getItem() {
        return item;
    }

    public String toCsvFormat() {
        return id + "," + item + "," + price + "," + stock + "," + maxSize + "," + lowTemp + "," + highTemp;
    }

    public String getPicFilename() {
        return id + ".jpg";
    }
}
