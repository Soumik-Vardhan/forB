package oop.ica.part2;

import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author : Sarika Akhil Yadav
 * @StudentID : S3215482
 */
public class YoFishTableModel extends AbstractTableModel {

    private String[] columnNames;
    private Object[][] data;

    public YoFishTableModel(String[] colNames, ArrayList<YoFishItem> itemList) {

        int columnNamesLength = colNames.length;

        columnNames = Arrays.copyOf(colNames, columnNamesLength);

        int rowLength = itemList.size();

        data = new Object[rowLength][columnNamesLength];

        for (int index = 0; index < itemList.size(); index++) {
            int id = itemList.get(index).getId();
            String item = itemList.get(index).getItem();
            double price = itemList.get(index).getPrice();
            int stock = itemList.get(index).getStock();
            double maxSize = itemList.get(index).getMaxSize();
            int lowTemp = itemList.get(index).getLowTemp();
            int highTemp = itemList.get(index).getHighTemp();

            Object[] dataRow = {id, item, price, stock, maxSize, lowTemp, highTemp};

            data[index] = Arrays.copyOf(dataRow, columnNamesLength);
        }
    }

    @Override
    public int getRowCount() {
        return data.length;
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data[rowIndex][columnIndex];
    }

    @Override
    public void setValueAt(Object value, int rowIndex, int columnIndex) {
        data[rowIndex][columnIndex] = value;
        fireTableCellUpdated(rowIndex, columnIndex);
    }

    public void updateData(ArrayList<YoFishItem> itemList) {
        int rowLength = itemList.size();
        int columnNamesLength = this.columnNames.length;
        this.data = new Object[rowLength][columnNamesLength];

        for (int index = 0; index < itemList.size(); index++) {
            int id = itemList.get(index).getId();
            String item = itemList.get(index).getItem();
            double price = itemList.get(index).getPrice();
            int stock = itemList.get(index).getStock();
            double maxSize = itemList.get(index).getMaxSize();
            int lowTemp = itemList.get(index).getLowTemp();
            int highTemp = itemList.get(index).getHighTemp();

            Object[] dataRow = {id, item, price, stock, maxSize, lowTemp, highTemp};

            this.data[index] = Arrays.copyOf(dataRow, columnNamesLength);
        }
        fireTableDataChanged();
    }

}
